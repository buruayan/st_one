
package click;


public interface OnClickListener {
    public void onClick();
}
