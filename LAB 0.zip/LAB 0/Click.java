package click;

public class Click {
    public static void main(String[]args){
    OnClickListener a = new OnClickListener(){
    public void onClick(){}
                                                };

}
}
